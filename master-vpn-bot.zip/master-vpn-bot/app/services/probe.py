"""Бесплатная выдача на ПРОБНЫХ условиях проекта.

Партнёрский триал (POST /trial) работает только на боевых условиях. Пока идёт проба (14 дней, 3 клиента),
API предлагает выдавать клиентов обычной выдачей по тарифу «Тест интеграции» – она бесплатна:
один заказ на клиента, 1–14 суток и не дальше конца условий пробы.
"""
from __future__ import annotations

import time

from ..partner.client import PartnerClient, PartnerError
from .plans import PlanCatalog


async def issue_probe(partner: PartnerClient, plans: PlanCatalog, tg_id: int, *, now: float | None = None) -> dict:
    plan = plans.developer
    if plan is None:
        raise PartnerError(409, {"code": "conflict", "error": "no developer plan"})
    terms = (await partner.balance()).get("terms") or {}
    expires = int(terms.get("expires_at_unix") or 0)
    days = int(plan["duration_days"])
    if expires:
        left_days = int((expires - (now if now is not None else time.time())) // 86400)
        days = min(days, left_days)
    if days < 1:  # до конца условий меньше суток
        raise PartnerError(409, {"code": "terms_expired", "error": "probe terms end in less than a day"})
    return await partner.put_user(f"tg-{tg_id}", plan["id"], days, f"probe-{tg_id}", max_charge_minor="0",
                                  metadata={"tg_id": tg_id, "source": "bot", "probe": True})
