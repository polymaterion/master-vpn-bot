import pytest

from app.partner.client import PartnerError
from app.services.plans import PlanCatalog
from app.services.probe import issue_probe

DAY = 86400


class ProbePartner:
    def __init__(self, expires):
        self.expires, self.calls = expires, []

    async def plans(self):
        return {"plans": [{"id": "dev", "kind": "developer", "device_limit": 2, "duration_days": 14}]}

    async def balance(self):
        return {"terms": {"expires_at_unix": self.expires}}

    async def put_user(self, ext, plan_id, days, key, **kw):
        self.calls.append((ext, plan_id, days, key, kw["max_charge_minor"]))
        return {"external_id": ext}


async def make(expires):
    partner = ProbePartner(expires)
    plans = PlanCatalog(partner)  # type: ignore[arg-type]
    await plans.refresh()
    assert plans.trial_project
    return partner, plans


async def test_days_clamped_to_remaining_probe_terms():
    now = 1_000_000
    partner, plans = await make(now + 6 * DAY + 3600)             # осталось 6 суток с хвостом
    await issue_probe(partner, plans, 5, now=now)  # type: ignore[arg-type]
    assert partner.calls == [("tg-5", "dev", 6, "probe-5", "0")]


async def test_full_14_days_when_plenty_left():
    now = 1_000_000
    partner, plans = await make(now + 30 * DAY)
    await issue_probe(partner, plans, 5, now=now)  # type: ignore[arg-type]
    assert partner.calls[0][2] == 14


async def test_less_than_a_day_left_is_refused():
    now = 1_000_000
    partner, plans = await make(now + 3600)
    with pytest.raises(PartnerError) as e:
        await issue_probe(partner, plans, 5, now=now)  # type: ignore[arg-type]
    assert e.value.code == "terms_expired" and not partner.calls
