"""Прогон всего дерева экранов через Navigator (без сети Telegram)."""
from __future__ import annotations

import pytest

from app.providers.cryptopay import CryptoPay
from app.providers.platega import Platega
from app.ui import screens  # noqa: F401
from app.ui.nav import Navigator, decode


class FakeBot:
    def __init__(self):
        self.sent: list[dict] = []

    async def send_message(self, chat_id, text, reply_markup=None, **kw):
        self.sent.append({"text": text, "kb": reply_markup, "photo": False})

    async def send_photo(self, chat_id, photo, caption=None, reply_markup=None, **kw):
        self.sent.append({"text": caption, "kb": reply_markup, "photo": True})


class PartnerStub:
    def __init__(self, user=None, devices=0):
        self._user, self._devices = user, devices

    async def user(self, ext):
        return self._user

    async def devices(self, ext):
        return {"devices": [{"device_id": str(i)} for i in range(self._devices)]}


def make_app(db, settings, user=None, devices=0):
    bot = FakeBot()
    app = type("A", (), {})()
    app.settings, app.db, app.bot = settings, db, bot
    app.partner = PartnerStub(user, devices)
    app.cryptopay = CryptoPay("", "https://x")
    app.platega = Platega(False)
    app.nav = Navigator(app)
    return app


def buttons(msg):
    return [b for row in msg["kb"].inline_keyboard for b in row]


def paid_user(devices=2, days=20):
    from datetime import timedelta
    from app.utils import utcnow
    return {"status": "active", "expires_at": (utcnow() + timedelta(days=days)).isoformat() + "Z", "device_limit": devices,
            "subscription_url": "https://sub.example.net/sub/abc", "traffic_used_bytes": "0",
            "traffic_limit_bytes": str(1024 ** 4), "white_used_bytes": "0", "white_limit_bytes": str(20 * 1024 ** 3)}


async def test_home_without_subscription_offers_buy(db, settings):
    app = make_app(db, settings)
    await app.nav.start(5)
    texts = [b.text for b in buttons(app.bot.sent[-1])]
    assert any("Купить" in t for t in texts) and any("Поддержка" in t for t in texts)
    assert not any("Назад" in t for t in texts)               # на главном экране «Назад» нет


async def test_back_is_exactly_one_level(db, settings):
    app = make_app(db, settings)
    await app.nav.start(5)
    await app.nav.push(5, None, "buy_term")
    await app.nav.push(5, None, "buy_devices", {"months": "3"})
    await app.nav.push(5, None, "buy_confirm", {"months": "3", "devices": "2"})
    await app.nav.back(5, None)
    assert [e["s"] for e in await app.nav.stack(5)] == ["home", "buy_term", "buy_devices"]
    await app.nav.back(5, None)
    await app.nav.back(5, None)
    await app.nav.back(5, None)                                # на корне остаёмся на корне
    assert [e["s"] for e in await app.nav.stack(5)] == ["home"]


async def test_active_paid_user_has_renew_but_no_buy(db, settings):
    app = make_app(db, settings, user=paid_user())
    await app.db.add_payment(__import__("app.db", fromlist=["PaymentRow"]).PaymentRow(
        id="p1", tg_id=5, provider="stars", kind="buy", months=1, devices=2, amount=1, currency="STARS", status="fulfilled"))
    await app.nav.start(5)
    home = [b.text for b in buttons(app.bot.sent[-1])]
    assert not any("Купить" in t for t in home)
    await app.nav.push(5, None, "sub")
    card = app.bot.sent[-1]
    assert "Устройств: <b>1 из 2</b>" not in card["text"] and "из 2" in card["text"]
    labels = [b.text for b in buttons(card)]
    assert any("Продлить" in t for t in labels) and not any("Купить" in t for t in labels) and any("Назад" in t for t in labels)


async def test_trial_user_can_only_buy_not_renew(db, settings):
    app = make_app(db, settings, user=paid_user(days=2))       # платных заказов нет – это триал
    await app.nav.push(5, None, "sub")
    labels = [b.text for b in buttons(app.bot.sent[-1])]
    assert any("Купить" in t for t in labels) and not any("Продлить" in t for t in labels)
    await app.nav.push(5, None, "buy_devices", {"months": "1"})
    device_buttons = [b for b in buttons(app.bot.sent[-1]) if "устр." in b.text]
    assert len(device_buttons) == 1                            # у действующего триала ступень менять нельзя


async def test_excess_devices_blocks_purchase_before_payment(db, settings):
    app = make_app(db, settings, user={**paid_user(devices=4, days=-1)}, devices=3)
    await app.nav.push(5, None, "buy_confirm", {"months": "1", "devices": "2"})
    msg = app.bot.sent[-1]
    assert "подключено устройств" in msg["text"] and not any("Оплатить" in b.text for b in buttons(msg))


async def test_payment_methods_show_prices_and_rub_is_stub(db, settings):
    app = make_app(db, settings)
    await app.nav.push(5, None, "pay_method", {"kind": "buy", "months": "1", "devices": "2"})
    labels = [b.text for b in buttons(app.bot.sent[-1])]
    assert any("Stars" in t for t in labels) and any("USDT" in t for t in labels) and any("Рубли" in t for t in labels)
    await app.nav.push(5, None, "pay_rub", {"kind": "buy", "months": "1", "devices": "2"})
    assert "скоро будет доступна" in app.bot.sent[-1]["text"]
    await app.nav.push(5, None, "pay_usdt", {"kind": "buy", "months": "1", "devices": "2"})
    assert "временно недоступен" in app.bot.sent[-1]["text"]   # токена CryptoPay нет


async def test_qr_screen_sends_photo(db, settings):
    app = make_app(db, settings, user=paid_user())
    await app.nav.push(5, None, "sub_qr")
    assert app.bot.sent[-1]["photo"] is True


async def test_callback_data_never_exceeds_limit(db, settings):
    app = make_app(db, settings, user=paid_user())
    for name, params in [("home", {}), ("sub", {}), ("renew_term", {}), ("renew_confirm", {"months": "6"}),
                         ("buy_term", {}), ("buy_devices", {"months": "6"}),
                         ("buy_confirm", {"months": "6", "devices": "8"}),
                         ("pay_method", {"kind": "renew", "months": "6", "devices": "8"}),
                         ("download", {}), ("info", {})]:
        await app.nav.push(5, None, name, params)
        for b in buttons(app.bot.sent[-1]):
            if b.callback_data:
                assert len(b.callback_data.encode()) <= 64, (name, b.callback_data)
